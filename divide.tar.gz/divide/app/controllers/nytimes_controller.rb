class NytimesController < ApplicationController

  def fetch
 

	require 'nokogiri'
	require 'open-uri'
	require 'rubygems'

	url = "http://www.nytimes.com"

	@page = Nokogiri::HTML(open(url))


	@title =@page.title
      
       
     #	page.css('.story-heading a').each do |element|
     #	@text = element.text.strip
     #	@link =  element['href']
     #	end

  end
end
