class SolutionsController < ApplicationController
  def Problems
  end
end
