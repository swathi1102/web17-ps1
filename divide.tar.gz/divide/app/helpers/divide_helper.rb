module DivideHelper
end
