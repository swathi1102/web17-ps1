class Quotation < ApplicationRecord


end
