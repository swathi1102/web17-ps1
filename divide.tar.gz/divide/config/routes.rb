Rails.application.routes.draw do
  get 'quotations/quote_index'

  get 'quotations/quote_show'

  get 'nytimes/fetch'

  get 'solutions/Problems'
  get '/Problems', to: 'solutions#Problems'
  get 'ps1_index/index'
  get 'divide/index'
  get '/index', to: 'divide#index'
  post 'divide/index'
  get 'divide/show'
  post 'divide/show'
  get 'nytimes/fetch'
  get '/fetch', to: 'nytimes#fetch'
  get 'ps1_index/quotations'
  post 'ps1_index/quotations'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  get '/quotations', to: 'ps1_index#quotations'
root "ps1_index#index"
end
