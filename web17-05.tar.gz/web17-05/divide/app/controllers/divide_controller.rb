class DivideController < ApplicationController

helper_method :show
 
     	def show
   		$num = params[:num]
   		print $num
   		$denom = params[:denom] 
   	
			print $num.to_f
     			$a = $num.to_f/ $denom.to_f
      			
		
		rescue ZeroDivisionError => e
		
  			logger.error "About to divide by zero : #{e.message}"
    			flash[:notice] = "Divided by zero!"
   		
      	end
   	
	def index
  	end
 
	def divide_params
      		params.require(:divide).permit(:num, :denom)
    	end
end
