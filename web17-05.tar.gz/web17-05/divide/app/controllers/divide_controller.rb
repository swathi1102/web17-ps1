class DivideController < ApplicationController

helper_method :show
 
     	def show
	  begin
   		@num = params[:num]
   		print $num
   		@denom = params[:denom] 
   		#print $num.to_i
     		@a = @num.to_i/ @denom.to_i
		
		rescue ZeroDivisionError => e
			@msg = e.message
  			logger.error "About to divide by zero : #{e.message}"
    			@msg1 =  "Divided by zero!"
			@error = "EXCEPTION BACTRACE: #{e.backtrace}"
			
   	   end
      	end
   	
	def index
  	end
 
	def divide_params
      		params.require(:divide).permit(:num, :denom)
    	end
end

