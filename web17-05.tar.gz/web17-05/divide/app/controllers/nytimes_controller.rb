require 'nokogiri'
require 'open-uri'
require 'rubygems'
class NytimesController < ApplicationController

  def fetch
 
	url = "https://www.nytimes.com"

	@page = Nokogiri::HTML(open(url))
	@title =@page.title      
       
     #	page.css('.story-heading a').each do |element|
     #	@text = element.text.strip
     #	@link =  element['href']
     #	end

  end
end
