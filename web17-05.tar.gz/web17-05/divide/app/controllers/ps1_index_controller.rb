class Ps1IndexController < ApplicationController
  def index
  end
end
