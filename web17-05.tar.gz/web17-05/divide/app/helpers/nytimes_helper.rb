module NytimesHelper
end
