require 'test_helper'

class NytimesControllerTest < ActionDispatch::IntegrationTest
  test "should get fetch" do
    get nytimes_fetch_url
    assert_response :success
  end

end
