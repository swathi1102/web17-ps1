require 'test_helper'

class Ps1IndexControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get ps1_index_index_url
    assert_response :success
  end

end
