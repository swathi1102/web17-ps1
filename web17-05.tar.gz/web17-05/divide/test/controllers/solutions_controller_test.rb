require 'test_helper'

class SolutionsControllerTest < ActionDispatch::IntegrationTest
  test "should get Problems" do
    get solutions_Problems_url
    assert_response :success
  end

end
